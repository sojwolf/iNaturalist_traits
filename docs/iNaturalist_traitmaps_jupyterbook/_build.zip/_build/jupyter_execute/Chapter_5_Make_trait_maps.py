#!/usr/bin/env python
# coding: utf-8

# # Make trait maps  

# In this section we will use R 

# In[1]:


library(raster)


# In[3]:


setwd('/net/home/swolf/iNaturalist/Data')


# In[4]:


#Load sPlot Data
sPlot <- read.csv('sPlotOpen/cwm_loc.csv')
#Load iNat Data
iNat <- read.csv('iNat_TRY_log.csv')


# In[5]:


head(sPlot)


# In[6]:


xy_1 <- cbind(sPlot$Longitude, sPlot$Latitude)
xy_2 <- cbind(iNat$decimalLongitude, iNat$decimalLatitude)


# In[7]:


r <- raster(ncols = 180, nrows = 90)


# In[8]:


# separate file for each trait

loop.vector <- 5:22

for (i in loop.vector) { # Loop over loop.vector
  vals_1 <- exp(sPlot[,i])
  name1 <- colnames(sPlot[i])
  r1 <- rasterize(xy_1, r, vals_1, fun = mean)
  r1[is.infinite(r1)] <- NA
  crs(r1) <- "+proj=longlat"
    
  vals_2 <- exp(iNat[name1])
  r2 <- rasterize(xy_2, r, vals_2, fun = mean)
  r2[is.infinite(r2)] <- NA
  crs(r2) <- "+proj=longlat"

  filename1 = paste("sPlot_", name1, "_0.5.tif", sep="")
  writeRaster(r1,filename1, overwrite=TRUE)
  filename2 = paste("iNat_", name1, "_0.5.tif", sep="")
  writeRaster(r2,filename2, overwrite=TRUE)
}

