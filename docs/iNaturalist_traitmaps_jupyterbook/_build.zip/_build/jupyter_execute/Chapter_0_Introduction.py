#!/usr/bin/env python
# coding: utf-8

# # Citizen science plant observations encode global trait patterns
# 
# 

# ## Publication
# 
# This Notebook documents the workflow of the paper "Citizen science plant observations encode global trait patterns" (Wolf et al.....).
# 
# 
# 

# ## Abstract
# 
# 
# With the increasing popularity of species identification smartphone apps, citizen scientists contribute to large and rapidly growing vegetation data collections. The question emerges whether such data can be utilized to monitor essential biodiversity variables across the globe. 
# 
# Here, we use the freely available field observations of vascular plants provided by iNaturalist, a citizen science project that has encouraged users across the globe to identify, share and jointly validate species they encounter via photo and geolocation. We test whether iNaturalist observations complemented with trait measurements from the TRY database (Kattge et al, 2020) are able to represent global trait patterns. 
# 
# As a reference for evaluating the iNaturalist observations, we use trait community-weighted means from the database sPlotOpen (Bruelheide et al, 2019; Sabatini et al, 2021). sPlotOpen is a curated database of globally distributed plots with vegetation abundance measurements, balanced over global climate and soil conditions. It provides community-weighted means for each vegetation plot for 18 traits. These community-weighted means are also derived from TRY measurements. We thus compare spatially and taxonomically biased occurrence samples provided by iNaturalist citizen scientists to professionally sampled environmentally balanced plot-based abundance data.
# 
# 

# ## Outline
# 
# 1. Preprocessing iNaturalist observation data - a first look
# 2. TRY summary statistics per species
# 3. Linking iNaturalist and TRY via species name
# 4. Preprcessing vegetation plot data (sPlotOpen)
# 5. Observation density in climate space
# 6. Trait maps: Compare iNaturalist and sPlotOpen
# 7. Alt. analysis: Aggregate iNaturalist in buffer around sPlots
# 8. Alt. analyses: Correlation Buffers
# 9. Differences among biomes 
# 
# 

# ## Packages needed for whole workflow
# 
# Here is the complete list of packages needed for this workflow. Each subsection lists the the packages needed for that section only.

# In[1]:


##############
# basics
import pandas as pd # for handling dataframes in python
import numpy as np # array handling
import os # operating system interfaces

##############
# for plotting
from matplotlib import pyplot as plt # main Python plotting library 
import seaborn as sns # pretty plots

import cartopy.crs as ccrs # maps 
import cartopy.feature as cfeature

import matplotlib.ticker as ticker
from matplotlib.ticker import MaxNLocator
from matplotlib.colors import LogNorm, Normalize, BoundaryNorm
from mpl_toolkits.axes_grid1 import make_axes_locatable

##############
# for gespatial data
import geopandas as gpd
# etc... to be added

